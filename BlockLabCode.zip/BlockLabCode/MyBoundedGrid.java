import java.util.ArrayList;

//A MyBoundedGrid is a rectangular grid with a finite number of rows and columns.
public class MyBoundedGrid<E>
{
	private Object[][] occupantArray;  // the array storing the grid elements

	//Constructs an empty MyBoundedGrid with the given dimensions.
	//(Precondition:  rows > 0 and cols > 0.)
	public MyBoundedGrid(int rows, int cols)
	{
		occupantArray = new Object[rows][cols];
	}

	//returns the number of rows
	public int getNumRows()
	{
		throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	//returns the number of columns
	public int getNumCols()
	{
		throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	//returns true if loc is valid in this grid, false otherwise
	//precondition:  loc is not null
	public boolean isValid(Location loc)
	{
		throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	//returns the object at location loc (or null if the location is unoccupied)
	//precondition:  loc is valid in this grid
	public E get(Location loc)
	{
		throw new RuntimeException("INSERT MISSING CODE HERE");

		//(You will need to promise the return value is of type E.)
	}

	//puts obj at location loc in this grid and returns the object previously at that location (or null if the
	//location is unoccupied)
	//precondition:  loc is valid in this grid
	public E put(Location loc, E obj)
	{
		throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	//removes the object at location loc from this grid and returns the object that was removed (or null if the
	//location is unoccupied
	//precondition:  loc is valid in this grid
	public E remove(Location loc)
	{
		throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	//returns an array list of all occupied locations in this grid
	public ArrayList<Location> getOccupiedLocations()
	{
		throw new RuntimeException("INSERT MISSING CODE HERE");
	}
}