public interface ArrowListener
{
	void upPressed();
	void downPressed();
	void leftPressed();
	void rightPressed();
}